## Notes for the reader

This chapter is based on a list of words to feed the brute force algo.

Both links suggested by the books are apparently broken. But I was able to find them on the web and you can find them in the repo for easiest ref. 

- SVN list could be downloaded from https://www.netsparker.com/blog/web-security/svn-digger-better-lists-for-forced-browsing/

- I wasn't able instead to find the source of the Cain and Abel one, so I downloaded it from this repo: https://github.com/duyet/bruteforce-database

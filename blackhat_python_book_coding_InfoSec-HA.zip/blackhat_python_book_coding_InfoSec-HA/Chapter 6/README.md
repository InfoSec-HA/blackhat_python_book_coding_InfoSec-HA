### Notes for the readers

- Quality of code in this chapter looks poorer than the previous ones. A tons of warnings to works on. Optimization of the code shown here is currently in progress. 
- You can download the latest Jython version from https://www.jython.org/download (as today jython-standalone-2.7.2.jar, direct link: https://repo1.maven.org/maven2/org/python/jython-standalone/2.7.2/jython-standalone-2.7.2.jar ) 
- If you need to install Burp Suite, you may find useful: https://www.kali.org/tools/burpsuite/ & https://blog.eldernode.com/configure-burp-suite-on-kali-linux/
- Even if was able to integrate Burp Suite with Python via .jar file, I wasn't able to successfully integrate the extensions. Therefore this chapter is still to be tested live.  
![burp1](https://user-images.githubusercontent.com/57464184/140102115-12a52560-92cb-46b0-8022-a4e2fce11ec9.png)
- To create the BING API Key, you may lead to https://www.microsoft.com/en-us/bing/apis/bing-web-search-api 

